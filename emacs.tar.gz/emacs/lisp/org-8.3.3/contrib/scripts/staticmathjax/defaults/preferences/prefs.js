pref("toolkit.defaultChromeURI", "chrome://staticmathjax/content/main.xul");
